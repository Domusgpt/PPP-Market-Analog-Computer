export const DATA_CHANNEL_COUNT = 32;

export const DEFAULT_PRIMARY_COLOR = new Float32Array([0.94, 0.3, 0.92]);
export const DEFAULT_SECONDARY_COLOR = new Float32Array([0.15, 0.85, 1.0]);
export const DEFAULT_BACKGROUND_COLOR = new Float32Array([0.02, 0.04, 0.08]);
